﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
namespace yazilimSinamaButunleme
{
    public class SHA256
    {
        public string encryptionSHA256(string plainText)
        {
            //SHA256Managed encryptionSHA256 = new SHA256Managed();
            //byte[] bytePlainText = System.Text.Encoding.UTF8.GetBytes(plainText);
            //string encryptedText = Convert.ToBase64String(encryptionSHA256.ComputeHash(bytePlainText));
            //return encryptedText;
            // Create a SHA256   
            byte[] bytes = Encoding.UTF8.GetBytes(plainText);
            byte[] hash = SHA256Managed.Create().ComputeHash(bytes);

            StringBuilder builder = new StringBuilder();
            for (int i = 0; i < hash.Length; i++)
            {
                builder.Append(hash[i].ToString("X2"));
            }

            return builder.ToString();
        }
        public string decryptionSHA256(string cryptedText)
        {
            SHA256Managed deencryptionSHA256 = new SHA256Managed();
            byte[] bytes = System.Text.Encoding.UTF8.GetBytes(cryptedText);
            byte[] hash = deencryptionSHA256.ComputeHash(bytes);
            string hashString = string.Empty;
            foreach (byte x in hash)
            {
                hashString += String.Format("{0:x2}", x);
            }
            return hashString;
        }

      
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

namespace yazilimSinamaButunleme
{
    public class AES
    {

        //public static byte[] AESCrypto(CryptoOperation cryptoOperation, AesCryptoServiceProvider aes, byte[] message)
        //{
        //    using (var memStream = new MemoryStream())
        //    {
        //        CryptoStream cryptoStream = null;

        //        if (cryptoOperation == CryptoOperation.ENCRYPT)
        //            cryptoStream = new CryptoStream(memStream, aes.CreateEncryptor(), CryptoStreamMode.Write);
        //        else if (cryptoOperation == CryptoOperation.DECRYPT)
        //            cryptoStream = new CryptoStream(memStream, aes.CreateDecryptor(), CryptoStreamMode.Write);

        //        if (cryptoStream == null)
        //            return null;

        //        cryptoStream.Write(message, 0, message.Length);
        //        cryptoStream.FlushFinalBlock();
        //        return memStream.ToArray();
        //    }

        //RijndaelManaged objrij = new RijndaelManaged();
        ////set the mode for operation of the algorithm
        //objrij.Mode = CipherMode.CBC;
        ////set the padding mode used in the algorithm.
        //objrij.Padding = PaddingMode.PKCS7;
        ////set the size, in bits, for the secret key.
        //objrij.KeySize = 0x80;
        ////set the block size in bits for the cryptographic operation.
        //objrij.BlockSize = 0x80;
        ////set the symmetric key that is used for encryption & decryption.
        //byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);
        ////set the initialization vector (IV) for the symmetric algorithm
        //byte[] EncryptionkeyBytes = new byte[] { 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };
        //int len = passBytes.Length;
        //if (len > EncryptionkeyBytes.Length)
        //{
        //    len = EncryptionkeyBytes.Length;
        //}
        //Array.Copy(passBytes, EncryptionkeyBytes, len);
        //objrij.Key = EncryptionkeyBytes;
        //objrij.IV = EncryptionkeyBytes;
        ////Creates symmetric AES object with the current key and initialization vector IV.
        //ICryptoTransform objtransform = objrij.CreateEncryptor();
        //byte[] textDataByte = Encoding.UTF8.GetBytes(textData);
        ////Final transform the test string.
        //return Convert.ToBase64String(objtransform.TransformFinalBlock(textDataByte, 0, textDataByte.Length));

        // public string DecryptData(string EncryptedText, string Encryptionkey)
        // {
        //RijndaelManaged objrij = new RijndaelManaged();
        //objrij.Mode = CipherMode.CBC;
        //objrij.Padding = PaddingMode.PKCS7;
        //objrij.KeySize = 0x80;
        //objrij.BlockSize = 0x80;
        //byte[] encryptedTextByte = Convert.FromBase64String(EncryptedText);
        //byte[] passBytes = Encoding.UTF8.GetBytes(Encryptionkey);
        //byte[] EncryptionkeyBytes = new byte[0x10];
        //int len = passBytes.Length;
        //if (len > EncryptionkeyBytes.Length)
        //{
        //    len = EncryptionkeyBytes.Length;
        //}
        //Array.Copy(passBytes, EncryptionkeyBytes, len);
        //objrij.Key = EncryptionkeyBytes;
        //objrij.IV = EncryptionkeyBytes;
        //byte[] TextByte = objrij.CreateDecryptor().TransformFinalBlock(encryptedTextByte, 0, encryptedTextByte.Length);
        //return Encoding.UTF8.GetString(TextByte);  //it will return readable string


        //string message = "The quick brown fox jumps over the lazy dog";
        //using (var aes = new AesCryptoServiceProvider())
        //{
        //    aes.GenerateIV();
        //    aes.GenerateKey();
        //    aes.Mode = CipherMode.CBC;
        //    aes.Padding = PaddingMode.PKCS7;

        //    byte[] encrypted = AESCrypto(CryptoOperation.ENCRYPT, aes, Encoding.UTF8.GetBytes(message));
        //    Console.WriteLine("Encrypted Text :" + BitConverter.ToString(encrypted).Replace("-", ""));
        //    byte[] decrypted = AESCrypto(CryptoOperation.DECRYPT, aes, encrypted);
        //    Console.WriteLine("Decrypted Text :" + Encoding.UTF8.GetString(decrypted));
        //}

        //}
        //public string encryptAES(string encryptStr, string key)
        //{
        //    byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key);
        //    byte[] toEncryptArray = UTF8Encoding.UTF8.GetBytes(encryptStr);
        //    RijndaelManaged rDel = new RijndaelManaged();
        //    rDel.Key = keyArray;
        //    rDel.Mode = CipherMode.ECB; //Encrypt mode
        //    rDel.Padding = PaddingMode.PKCS7;   //Fill mode
        //    ICryptoTransform cTransform = rDel.CreateEncryptor();
        //    byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
        //    return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        //}
        //public  string DecryptAES(string decryptStr, string key)
        //{
        //    byte[] keyArray = UTF8Encoding.UTF8.GetBytes(key);
        //    byte[] toEncryptArray = Convert.FromBase64String(decryptStr);
        //    RijndaelManaged rDel = new RijndaelManaged();
        //    rDel.Key = keyArray;
        //    rDel.Mode = CipherMode.ECB;
        //    rDel.Padding = PaddingMode.PKCS7;
        //    ICryptoTransform cTransform = rDel.CreateDecryptor();
        //    byte[] resultArray = cTransform.TransformFinalBlock(toEncryptArray, 0, toEncryptArray.Length);
        //    return UTF8Encoding.UTF8.GetString(resultArray);
        //}
        private const string AES_IV = @"!&+QWSDF!123126+"; //!&+QWSDF!123126
        private string aesAnahtar = @"QQsaw!257()%%ert";

        public string encryptAES(string plainText)
        {
            AesCryptoServiceProvider aesSaglayici = new AesCryptoServiceProvider();
            aesSaglayici.BlockSize = 128;
            aesSaglayici.KeySize = 128;

            aesSaglayici.IV = Encoding.UTF8.GetBytes(AES_IV);
            aesSaglayici.Key = Encoding.UTF8.GetBytes(aesAnahtar);
            aesSaglayici.Mode = CipherMode.CBC;
            aesSaglayici.Padding = PaddingMode.PKCS7;

            byte[] kaynak = Encoding.Unicode.GetBytes(plainText);
            using (ICryptoTransform sifrele = aesSaglayici.CreateEncryptor())
            {
                byte[] hedef = sifrele.TransformFinalBlock(kaynak, 0, kaynak.Length);
                return Convert.ToBase64String(hedef);
            }
        }
        public string decryptAES(string encryptedText)
        {
            AesCryptoServiceProvider aesSaglayici = new AesCryptoServiceProvider();
            aesSaglayici.BlockSize = 128;
            aesSaglayici.KeySize = 128;

            aesSaglayici.IV = Encoding.UTF8.GetBytes(AES_IV);
            aesSaglayici.Key = Encoding.UTF8.GetBytes(aesAnahtar);
            aesSaglayici.Mode = CipherMode.CBC;
            aesSaglayici.Padding = PaddingMode.PKCS7;

            byte[] kaynak = System.Convert.FromBase64String(encryptedText);
            using (ICryptoTransform decrypt = aesSaglayici.CreateDecryptor())
            {
                byte[] hedef = decrypt.TransformFinalBlock(kaynak, 0, kaynak.Length);
                return Encoding.Unicode.GetString(hedef);
            }
        }

    }
}

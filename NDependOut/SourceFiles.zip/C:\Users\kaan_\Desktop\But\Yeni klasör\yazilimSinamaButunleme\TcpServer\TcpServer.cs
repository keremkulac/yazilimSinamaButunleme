﻿//using DatabaseOperation;
using SimpleTcp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using TcpServer;

namespace yazilimSinamaButunleme
{
    public partial class TcpServer : Form
    {
        SimpleTcpServer server;
        TcpListener list;
        public TcpServer()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;  
            this.Location = new Point(100, 250);
            clear();
        }
        
     
        private void btnStart_Click(object sender, EventArgs e)
        {
            server.Start();
            txtInfo.Text += $"Starting...{Environment.NewLine}";
            btnStart.Enabled = false;
            btnSend.Enabled = true;
         
        }
        public void fillDgvAndRefresh()
        {
            dgvFindMessage.DataSource = operations.refresh();
        }
       
        private void TcpServer_Load(object sender, EventArgs e)
        {

            fillDgvAndRefresh();
            btnSend.Enabled = false;
            server = new SimpleTcpServer(txtIP.Text, Convert.ToInt32(txtPort.Text));
            server.Events.ClientConnected += Events_ClientConnected;
            server.Events.ClientDisconnected += Events_ClientDisconnected;
            server.Events.DataReceived += Events_DataReceived;         
        }
       
        private void Events_DataReceived(object? sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                txtInfo.Text += $"{e.IpPort}:{Encoding.UTF8.GetString(e.Data)}{Environment.NewLine}";

            });
        }

        private void Events_ClientDisconnected(object? sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                txtInfo.Text += $"{e.IpPort} disconnected.{Environment.NewLine}";
                lstClientIP.Items.Remove(e.IpPort);
            });
         
        }

        private void Events_ClientConnected(object? sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                txtInfo.Text += $"{e.IpPort} connected.{Environment.NewLine}";
                lstClientIP.Items.Add(e.IpPort);
            });  
        }
        DatabaseOperation operations = new DatabaseOperation();   
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (server.IsListening)
            {
                // check message &  select client ip from listbox
                if (!string.IsNullOrEmpty(txtMessage.Text) && lstClientIP.SelectedItem != null)
                {
                    server.Send(lstClientIP.SelectedItem.ToString(), txtMessage.Text);   
                    txtInfo.Text += $"Server: {txtMessage.Text}{Environment.NewLine}";
                    operations.addMessage("Server", txtMessage.Text);
                    txtMessage.Text = string.Empty;
                }
                else
                {
                    MessageBox.Show("Enter a message or choose an ip ");
                }
            }
            fillDgvAndRefresh();

        }

        private void btnEncrypt_Click(object sender, EventArgs e)

        {
            string key = "12345678";
            SHA256 sha256 = new SHA256();
            SPN spn = new SPN();
            AES aes = new AES();
            DES des = new DES();
            if(String.IsNullOrWhiteSpace(txtEncryptMessage.Text) || String.IsNullOrEmpty(txtEncryptMessage.Text))
            {
                MessageBox.Show("Please enter a message.");
            }
            else
            {
                if ((rbSHA256.Checked ) || (rbSPN.Checked ) || (rbAES.Checked) || (rbDES.Checked))
                {
                    if (rbSHA256.Checked)
                    {
                        txtEncryptedMessage.Text = sha256.encryptionSHA256(txtEncryptMessage.Text);
                    }
                    else if (rbAES.Checked)
                    {
                        txtEncryptedMessage.Text = aes.encryptAES(txtEncryptMessage.Text);
                    }
                    else if (rbDES.Checked)
                    {
                        txtEncryptedMessage.Text = des.EncryptionDES(txtEncryptMessage.Text,key);
                    }
                    
                }
                else { 
                    MessageBox.Show("Please select an encryption type");
                }
            }
            clear();


        }
        public void clear()
        {
            txtEncryptMessage.Text = "";
            rbSHA256.Checked = false;
            rbSPN.Checked = false;
            rbAES.Checked = false;
            rbDES.Checked = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEncryptedMessage.Text = "";
            clear();
        }

        private void btnSendFile_Click(object sender, EventArgs e)
        {
            //IPAddress ipAddress = IPAddress.Parse(GetLocalIp());
            //int port = int.Parse(txtLocalPort.Text);
            //var file = new OpenFileDialog();
            //file.Multiselect = true;
            //file.Title = "Select Files";

            //if (file.ShowDialog() == DialogResult.OK)
            //    foreach (string fileName in file.FileNames)
            //    {
            //        sifreleAsync(fileName);
            //        string[] splitDosya = fileName.Split(".");
            //        string filePath = splitDosya[0] + ".zip";
            //        MessageBox.Show("Dosya başarıyla gönderildi.");
            //        new Thread(() =>
            //        {
            //            Sender.Send(ipAddress, port, filePath);
            //        }).Start();
            //    }
            //file.Dispose();
        }
       
        private void btnBrowse_Click(object sender, EventArgs e)
        {
           

        }

        private void txtFindMessage_TextChanged(object sender, EventArgs e)
        {
            dgvFindMessage.DataSource = operations.List("Select * from Messages where Message like '%" + txtFindMessage.Text + "%' or Date like '%"+ txtFindMessage.Text +"%'");    
        }

    }

  }


﻿//using DatabaseOperations;
using SimpleTcp;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using yazilimSinamaButunleme;
namespace yazilimSinamaButunleme
{
    public partial class TcpClient : Form
    {
        TcpServer tcpServer = new TcpServer();
        SimpleTcpClient client;
        DatabaseOperation databaseOperation = new DatabaseOperation();   
        SHA256 sHA256 = new SHA256();   
       
        public TcpClient()
        {
            InitializeComponent();
            this.StartPosition = FormStartPosition.Manual;
            this.Location = new Point(800, 250);
        }
        
        private void btnConnect_Click(object sender, EventArgs e)
        {
            try
            {
                client.Connect();
                btnSend.Enabled = true;
                btnConnect.Enabled = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
          
        }
      
   
        private void btnSend_Click(object sender, EventArgs e)
        {
            if (client.IsConnected)
            {
                if (!string.IsNullOrEmpty(txtMessage.Text))
                {
                    client.Send(txtMessage.Text);
                    txtInfo.Text += $"Me:{txtMessage.Text}{Environment.NewLine}";
                    databaseOperation.addMessage("Client",txtMessage.Text);
                    txtMessage.Text = string.Empty;
                }
                else
                {
                    MessageBox.Show("Enter a message ");
                }

            }
            fillDgvAndRefresh();
        }
    
        public void fillDgvAndRefresh()
        {
            dgvFindMessage.DataSource = databaseOperation.refresh();
        }


        private void TcpClient_Load(object sender, EventArgs e)
        {
            fillDgvAndRefresh();
            client = new(txtIP.Text,Convert.ToInt32(txtPort.Text));
            client.Events.Connected += Events_Connected;
            client.Events.Disconnected += Events_Disconnected;
            client.Events.DataReceived += Events_DataReceived;
            btnSend.Enabled = false;
        }

        private void Events_DataReceived(object? sender, DataReceivedEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                 txtInfo.Text += $"Server: {Encoding.UTF8.GetString(e.Data)}{Environment.NewLine}";
            });

        }

        private void Events_Disconnected(object? sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                txtInfo.Text += $"Server disconnected.{Environment.NewLine}";
            });
        }

        private void Events_Connected(object? sender, ConnectionEventArgs e)
        {
            this.Invoke((MethodInvoker)delegate
            {
                txtInfo.Text += $"Server connected.{Environment.NewLine}";
            });

        }

        private void txtFindMessage_TextChanged(object sender, EventArgs e)
        {
            dgvFindMessage.DataSource = databaseOperation.List("Select * from Messages where Message like '%" + txtFindMessage.Text + "%' or Date like '%" + txtFindMessage.Text + "%'");
        }

        private void btnEncrypt_Click(object sender, EventArgs e)

        {
            string key = "12345678";
            SHA256 sha256 = new SHA256();
            SPN spn = new SPN();
            AES aes = new AES();
            DES des = new DES();
            if (String.IsNullOrWhiteSpace(txtEncryptMessage.Text) || String.IsNullOrEmpty(txtEncryptMessage.Text))
            {
                MessageBox.Show("Please enter a message.");
            }
            else
            {
                if ((rbSHA256.Checked) || (rbSPN.Checked) || (rbAES.Checked) || (rbDES.Checked))
                {
                    if (rbSHA256.Checked)
                    {
                        txtEncryptedMessage.Text = sha256.encryptionSHA256(txtEncryptMessage.Text);
                    }
                    else if (rbAES.Checked)
                    {
                        txtEncryptedMessage.Text = aes.encryptAES(txtEncryptMessage.Text);
                    }
                    else if (rbDES.Checked)
                    {
                        txtEncryptedMessage.Text = des.EncryptionDES(txtEncryptMessage.Text, key);
                    }

                }
                else
                {
                    MessageBox.Show("Please select an encryption type");
                }
            }
            clear();


        }
        public void clear()
        {
            txtEncryptMessage.Text = "";
            rbSHA256.Checked = false;
            rbSPN.Checked = false;
            rbAES.Checked = false;
            rbDES.Checked = false;
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEncryptedMessage.Text = "";
            clear();
        }

     
    }
}
